package com.myproject;

public interface AnimalActions {
    public void learnAboutClass();
}
